from iota_sdk import Wallet
import json
import rw_json_file

data = rw_json_file.read("config.json")
wallet = Wallet(data['DI_WALLET_DB_PATH'])

account = wallet.get_account('DistAccount')

# Sync account with the node
_balance = account.sync()

# Just calculate the balance with the known state
balance = account.get_balance()
print(f'Balance {json.dumps(balance.as_dict(), indent=4)}')