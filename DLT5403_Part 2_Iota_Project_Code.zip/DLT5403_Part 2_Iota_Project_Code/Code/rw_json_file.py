import json

def read(filename):
    try:
        with open(filename, "r") as jsonfile:
            data = json.load(jsonfile)
            jsonfile.close()
        return data
    except:
        return ""
    
def write(filename, data):
    write_json = json.dumps(data, indent=2)
    try:
        with open(filename, "w") as jsonfile:
            jsonfile.write(write_json)
            jsonfile.close()
    except:
        pass

