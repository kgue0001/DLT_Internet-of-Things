from iota_sdk import Utils
import rw_json_file

data = rw_json_file.read("config.json")
# Generate a random BIP39 mnemonic
mnemonic = Utils.generate_mnemonic()
print(f'Mnemonic: {mnemonic}')
data["DI_MNEMONIC"] = mnemonic
rw_json_file.write("config.json", data)
