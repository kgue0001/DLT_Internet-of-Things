import rw_json_file


data = rw_json_file.read("config.json")

data["STRONGHOLD_PASSWORD"] = "TESTING"

rw_json_file.write("config.json", data)