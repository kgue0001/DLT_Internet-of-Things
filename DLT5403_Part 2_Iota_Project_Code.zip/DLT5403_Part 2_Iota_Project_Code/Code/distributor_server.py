from flask import Flask, request
import requests
from time import time as ts
from time import sleep as delay_s
from random import randint
import json
app = Flask(__name__)


@app.route("/PlaceOrder", methods=['POST'])
def handleOrder():
    d = request.get_json()
    requests.post("http://localhost:5000/generatePackageId", json = d)
    start = ts()
    while ((ts() - start) < 10):
        resp = requests.get("http://localhost:5000/readmessage")
        if(resp.text != ""):
            txt = resp.text
            idx = txt.index("GPIDR")
            if(idx >= 0):
                obj = json.loads(txt[idx+5::])
                obj["knocks"] = randint(1, 9)
                print(json.dumps(obj))
                requests.post("http://localhost:5002/deliverOrder", data=json.dumps(obj))
                requests.post("http://localhost:5003/outForDelivery", data=json.dumps(obj))
            return "OK"
        delay_s(1)
    return "Delivery Could Not Be Initiated"

@app.route("/")
def home():
    return '''<!DOCTYPE html>
<html>
<head>
  <title>Place Order</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .container {
      background-color: #fff;
	  margin-top: 20px;
      padding: 40px;
      border-radius: 5px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      text-align: center;
	  width: 60%;
    }

    h1 {
      margin-bottom: 20px;
      color: #333;
    }

    label {
      display: block;
      margin-bottom: 10px;
      color: #555;
    }

    input[type="text"] {
      padding: 10px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 16px;
    }

    button[type="submit"] {
      background-color: #007bff;
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button[type="submit"]:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
<center>
  <div class="container">
    <h1>Initiate Delivery</h1>
    <form id="orderForm">
      <label for="orderId">Order ID:</label>
      <input type="text" id="orderId" name="orderId" required>
      <button type="submit">Initiate</button>
    </form>
  </div>
</center>
  <script>
    const orderForm = document.getElementById('orderForm');

    orderForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const orderId = document.getElementById('orderId').value;

      const response = await fetch('PlaceOrder', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ orderId })
      });

      const msg = await response.text();

      if (msg == "OK") {
        alert('Delivery Initiated');
      } else {
        alert('Error initiating delivery');
      }
    });
  </script>
</body>
</html>'''
    
if __name__ == "__main__":
    app.run(debug=True, port=5001)