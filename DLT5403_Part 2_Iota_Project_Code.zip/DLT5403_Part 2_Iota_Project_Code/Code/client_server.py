from flask import Flask, request
import requests
from time import time as ts
from time import sleep as delay_s
from random import randint
import json
app = Flask(__name__)


from iota_sdk import Client, MnemonicSecretManager, AddressAndAmount, utf8_to_hex, hex_to_utf8
import rw_json_file

data = rw_json_file.read("config.json")

node_url = data['NODE_URL']

# Create a Client instance
client = Client(nodes=[node_url])

secret_manager = MnemonicSecretManager(
    data['CL_MNEMONIC'])

address_and_amount = AddressAndAmount(
    1000000,
    data["DISTRIBUTOR_ADDRESS"],
)

current_delivery_order_id = ""
current_delivery_package_id = ""
current_delivery_knocks = 0

@app.route("/verifyKnocks", methods=['POST'])
def handleVerifyKnocks():
    global current_delivery_order_id, current_delivery_package_id, current_delivery_knocks
    d = request.get_data()
    d_str = d.decode()
    obj = json.loads(d_str)
    v_knocks = int(obj["knocks"])
    print(current_delivery_knocks)
    print(v_knocks)
    if(v_knocks == current_delivery_knocks):
        print("Knock Verified")
        requests.get("http://localhost:5000/unlockDevice")
        block = client.build_and_post_block(secret_manager, output=address_and_amount,tag=utf8_to_hex('Delivery') , data=utf8_to_hex('Delivery'))
        print(f'IOTA sent: {data["EXPLORER_URL"]}/block/{block[0]}')
    #print(current_delivery_knocks)
    #print(v_knocks)
    return "OK"

@app.route("/outForDelivery", methods=['POST'])
def handleDelivery():
    global current_delivery_order_id, current_delivery_package_id, current_delivery_knocks
    d = request.get_data()
    d_str = d.decode()
    obj = json.loads(d_str)
    current_delivery_order_id = str(obj["orderId"])
    current_delivery_package_id = str(obj["packageId"])
    current_delivery_knocks = int(obj["knocks"])

    print(current_delivery_order_id)
    print(current_delivery_package_id)
    print(current_delivery_knocks)
    return "OK"

if __name__ == "__main__":
    app.run(debug=True, port=5003)