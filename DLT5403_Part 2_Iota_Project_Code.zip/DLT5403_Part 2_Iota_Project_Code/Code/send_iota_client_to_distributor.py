from iota_sdk import Client, MnemonicSecretManager, AddressAndAmount, utf8_to_hex, hex_to_utf8
import rw_json_file

data = rw_json_file.read("config.json")

node_url = data['NODE_URL']

# Create a Client instance
client = Client(nodes=[node_url])

secret_manager = MnemonicSecretManager(
    data['CL_MNEMONIC'])

address_and_amount = AddressAndAmount(
    1000000,
    data["DISTRIBUTOR_ADDRESS"],
)

# Create and post a block with a transaction
block = client.build_and_post_block(secret_manager, output=address_and_amount, tag=utf8_to_hex('hello'), data=utf8_to_hex('hello'))
print(f'Block sent: {data["EXPLORER_URL"]}/block/{block[0]}')