from iota_sdk import Wallet, StrongholdSecretManager, CoinType, ClientOptions
import os

import rw_json_file
data = rw_json_file.read("config.json")

# This example creates a new database and account

node_url = data['NODE_URL']
client_options = ClientOptions(nodes=[node_url])

# Shimmer coin type
coin_type = CoinType.SHIMMER

secret_manager = StrongholdSecretManager( data['DI_STRONGHOLD_SNAPSHOT_PATH'], data['DI_STRONGHOLD_PASSWORD'])

wallet = Wallet(
    data['DI_WALLET_DB_PATH'],
    client_options,
    coin_type,
    secret_manager)

# Store the mnemonic in the Stronghold snapshot, this only needs to be
# done once.
wallet.store_mnemonic(data['DI_MNEMONIC'])

account = wallet.create_account('DistAccount')
print("Account created:", account.get_metadata())