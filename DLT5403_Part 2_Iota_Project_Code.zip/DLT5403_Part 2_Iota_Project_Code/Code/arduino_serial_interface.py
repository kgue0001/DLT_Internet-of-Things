from flask import Flask, request, jsonify
import serial
import threading
import time
import requests
import json
#knock it once
#again
# packaging bot / knock lock
SERIAL_PORT = "COM5"
BAUDRATE = 9600
ser = serial.Serial(SERIAL_PORT, BAUDRATE)
app = Flask(__name__)
global_ser_resp = ""

def run_serial_thread():
    global global_ser_resp
    while True:
        if ser.in_waiting > 0:
            time.sleep(0.5)
            st = ""
            while ser.in_waiting > 0:
                c = ser.read().decode()
                st += c
            print(st)
            global_ser_resp = st
            try:
                if(st.index("KNCKR:") >= 0):
                    knocks = st[st.index("KNCKR:")+6::]
                    obj = {}
                    obj["knocks"] = knocks
                    requests.post("http://localhost:5003/verifyKnocks", data=json.dumps(obj))
            except:
                pass
        time.sleep(0.1)

@app.route('/')
def use_serial():
    return 'use flask serial!'

@app.route("/generatePackageId", methods=['POST'])
def generatePackageId():
    d = request.get_data()
    ser.write("GPID".encode())
    ser.write(d)
    ser.write("\r\n".encode())
    return "OK"

@app.route("/unlockDevice")
def unlockDevice():
    d = request.get_data()
    ser.write("UNLKD".encode())
    ser.write("\r\n".encode())
    return "OK"

@app.route("/readmessage")
def read_message():
    global global_ser_resp
    rd = global_ser_resp
    global_ser_resp = ""
    return rd

if __name__ == '__main__':
    serial_thread = threading.Thread(target=run_serial_thread)
    serial_thread.setDaemon(True)
    serial_thread.start()

    app.run(debug=False)


# while True:
#     print("Here")
#     time.sleep(2)
# from flask import Flask, request, jsonify
# from flask_serial import Serial
# import requests
# import json
# import time
# app = Flask(__name__)
# app.config['SERIAL_TIMEOUT'] = 0.001
# app.config['SERIAL_PORT'] = 'COM5'
# app.config['SERIAL_BAUDRATE'] = 9600
# app.config['SERIAL_BYTESIZE'] = 8
# app.config['SERIAL_PARITY'] = 'N'
# app.config['SERIAL_STOPBITS'] = 1


# ser =Serial(app)

# wait_for_data = False
# global_ser_resp = ""

# def allzero(msg):
#     for x in msg:
#         if(x != 0x00):
#             return False
#     return True

# @app.route('/')
# def use_serial():
#     return 'use flask serial!'

# @app.route("/on")
# def ledOn():
#     ser.on_send("ON\r\n")
#     return "OK"

# @app.route("/off")
# def ledOff():
#     ser.on_send("OFF\r\n")
#     return "OK"

# @app.route("/send", methods=['POST'])
# def send_message():
#     d = request.get_data()
#     ser.on_send(d)
#     return "OK"

# @app.route("/generatePackageId", methods=['POST'])
# def generatePackageId():
#     d = request.get_data()
#     ser.on_send("GPID")
#     ser.on_send(d)
#     ser.on_send("\r\n")
#     return "OK"

# @app.route("/unlockDevice")
# def unlockDevice():
#     d = request.get_data()
#     ser.on_send("UNLKD")
#     ser.on_send("\r\n")
#     return "OK"

# @app.route("/readmessage")
# def read_message():
#     global global_ser_resp
#     rd = global_ser_resp
#     global_ser_resp = ""
#     return rd

# @ser.on_message()
# def handle_message(msg):
#     global wait_for_data, global_ser_resp
#     #print("message:", msg)
#     z = allzero(msg)
#     if z == False:
#         st = msg.decode()
#         print("receive a message:", st)
#         global_ser_resp = st
#         if(st.index("KNCKR:") >= 0):
#             knocks = st[st.index("KNCKR:")+6::]
#             obj = {}
#             obj["knocks"] = knocks
#             requests.post("http://localhost:5003/verifyKnocks", data=json.dumps(obj))
#             #TODO:: Call Client API to Verify Knock
#             #print("Send Knock")
#             #print()

#     # send a msg of str
#     #ser.on_send("send a str message!!!")
#     # send a msg of bytes
#     #ser.on_send(b'send a bytes message!!!')

# if __name__ == '__main__':
#     app.run(debug=False)
    