from flask import Flask, request
import requests
from time import time as ts
from time import sleep as delay_s
from random import randint
import json
app = Flask(__name__)

# no of random knocks  1-9
@app.route("/deliverOrder", methods=['POST'])
def handleDelivery():
    d = request.get_data()
    print(d)
    return "OK"

if __name__ == "__main__":
    app.run(debug=True, port=5002)