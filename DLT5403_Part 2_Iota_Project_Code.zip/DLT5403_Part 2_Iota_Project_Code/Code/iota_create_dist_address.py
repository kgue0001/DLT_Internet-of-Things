from iota_sdk import Wallet
import rw_json_file

data = rw_json_file.read("config.json")

wallet = Wallet(data['DI_WALLET_DB_PATH'])
wallet.set_stronghold_password(data["DI_STRONGHOLD_PASSWORD"])

account = wallet.get_account('DistAccount')
address = account.generate_ed25519_addresses(1)

print(f'Generated address:', address[0].address)
data["DISTRIBUTOR_ADDRESS"] = address[0].address
rw_json_file.write("config.json", data)